Avatars for Figma
=================

Install (Figma desktop app):

  1. Open the Figma desktop app. Import works in the desktop app only.
  2. Open any file.
  3. Menu: Plugins -> Development -> Import plugin from manifest...
  4. Choose the manifest.json in this folder.
  5. Run it from Plugins -> Development -> Avatars.

Keep this folder where it is. Figma reads the plugin from these files each
time it runs, so it must stay on disk.

The plugin needs no network. Every avatar is generated from its seed on the
spot. Nothing is fetched and nothing is uploaded.

Docs: https://avatars.outpacestudios.com/figma-plugin
